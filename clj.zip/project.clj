(defproject clojure-tim "0.1"
  :description "Tim"
  :dependencies [[org.clojure/clojure "1.2.0-RC1"]
                 [org.clojure/clojure-contrib "1.2.0-RC1"]]
  :dev-dependencies [[swank-clojure "1.2.0"]])
