;; A namespace dedicated to defrecord's

(ns clj-webdriver.record)

(defrecord WindowHandle [driver handle title url])