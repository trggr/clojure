(ns ncparse.ddl
  (:use [clojure.string :as s :exclude [replace reverse join]]
        [clojure.contrib.str-utils]
	[clojure.xml :as xml]))

(defn seg?
  "Returns true, if e is a segment of a tree"
  [e]
  (when e
    (map? ((:content e) 0))))

(defn csv
  "Separates the items of a sequence by an arbitrary value"
  [coll val]
  (if (empty? coll)
    coll
    (reduce #(conj %1 val %2) [(first coll)] (rest coll))))

(defn sql-name
  "Converts a keyword into a nice table or column name suitable for SQL usage"
  [kw]
  (s/replace (.toLowerCase (name kw)) "-" "_"))

(defn ddl-create
  "Retruns SQL create statement"
  [tab cols]
  (str "create table " tab " (\n"
       (apply str "  " (csv (keys cols) " varchar(50),\n  "))
       " varchar(50)\n)@"))

(defn ddl-insert
  "Retuns SQL insert statement for table tab with columns cols"
  [tab cols]
  (str "insert into " tab " ("
       (apply str (csv (keys cols) ", "))
       ")\nvalues (\""
       (apply str (csv (vals cols) "\", \""))
       "\")@"))

(defn emit-elt
  [e]
  (let [tab (sql-name (:tag e))
	nodes (filter (complement seg?) (:content e))
	segs (filter seg? (:content e))
	cols (zipmap (map #(sql-name (:tag %)) nodes)
		     (map #(first (:content %)) nodes))]
    (println (ddl-create tab cols))
    (println (ddl-insert tab cols))
    (doseq [s segs]
      (emit-elt s))))

(defn emit-elt
  ""
  [e parent]
  (let [[fk fkid] parent
	tab (sql-name (:tag e))
	nodes (filter (complement seg?) (:content e))
	pk   (str tab "_id")
	pkid 1
	z1 (-> (zipmap (map #(sql-name (:tag %)) nodes)
		       (map #(first (:content %)) nodes))
	       (assoc pk pkid))
	cols (if fk (assoc z1 fk fkid) z1)]
    (println (ddl-create tab cols))
    (println (ddl-insert tab cols))
    (doseq [s (filter seg? (:content e))]
      (emit-elt s (vector pk pkid)))))
